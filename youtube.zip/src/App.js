import Header from "./components/Header/Header";
import './App.css';
import SideNavSvg from "./components/SideNav/SideNavSvg";
import Videos from "./Videos.js";

function App() {
  return (
    <div className="App">
      <Header />
      <div className="yt-main" style={{ "display": "flex" }}>
        <SideNavSvg />
        <Videos />
      </div>

    </div>
  );
}

export default App;
