import React from 'react'
import './Header.css';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import AppsIcon from '@mui/icons-material/Apps';

function Header() {
    return (
        <div className="header">
            <div className="header_left">
                <MenuIcon />
                <img className="yt-img" src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Logo_of_YouTube_%282015-2017%29.svg" alt="youTube Logo" />
            </div>
            <div className="header-mid">
                <input type="text" className="search-box" placeholder="Search" />
                <div className="search-icon-main"> <SearchIcon className="searchIcon"></SearchIcon></div>
            </div>
            <div className="header-right">
                <VideoCallIcon className="vcall-icon"></VideoCallIcon >
                <AppsIcon className="notif-icon"></AppsIcon >
            </div>

        </div>
    )

}

export default Header;
