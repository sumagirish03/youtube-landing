import React from 'react';
import './Filter.css';

const Filter = () => {
    return (
        <div className="nav-filter flex item-center">
           <div className="first-fil">
               <span className="fil-items pointer active">All</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Movies</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">videos</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer">Music</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">News</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Live</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Mixes</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Playlists</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Games</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Yoga</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Puppies</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Stories</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Singers</span>
           </div>
           <div className="first-fil">
               <span className="fil-items pointer ">Gardening</span>
           </div>
            <div>
            <svg viewBox="8 0 16 20" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope yt-icon" style={{width: "20px", height: "20px", margin:"0px 15px;"}}><g mirror-in-rtl="" class="style-scope yt-icon"><path d="M9.4,18.4l-0.7-0.7l5.6-5.6L8.6,6.4l0.7-0.7l6.4,6.4L9.4,18.4z" class="style-scope yt-icon"></path></g></svg>
            </div>
        </div>
    )
}

export default Filter
