import React from "react";
import './SideNav.css';
import MenuItems from './../MenuItems/MenuItems';
import HomeIcon from '@mui/icons-material/Home';
import WhatshotIcon from '@mui/icons-material/Whatshot';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import VideoLibraryIcon from '@mui/icons-material/VideoLibrary';
import HistoryIcon from '@mui/icons-material/History';
import OndemandVideoIcon from '@mui/icons-material/OndemandVideo';
import WatchLaterIcon from '@mui/icons-material/WatchLater';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';

const sideNav = () => {
    return (
        <div className='side-nav'>
        
            <MenuItems selected Icon={HomeIcon} title='Home' />
            <MenuItems Icon={WhatshotIcon} title='Trending' />
            <MenuItems Icon={SubscriptionsIcon} title='Subscription' />
            <hr />
            <MenuItems Icon={VideoLibraryIcon} title='Library' />
            <MenuItems Icon={HistoryIcon} title='History' />
            <MenuItems Icon={OndemandVideoIcon} title='Your videos' />
            <MenuItems Icon={WatchLaterIcon} title='Watch later' />
            <MenuItems Icon={ThumbUpIcon} title='Liked vides' />
            <hr />

            {/* <ul className="Nav-items-ul">
                <li Icon={HomeIcon} title='Home'>{HomeIcon} Home</li>
                <li>Shorts</li>
                <li>Subscriptions</li>
            </ul>
            <hr />
            <ul className="Nav-items-ul">
                <li>LIbrary</li>
                <li>History</li>
                <li>Watch Later</li>
                <li>LIked Videos</li>
            </ul>
            <h4>Subscriptions</h4>
            <ul className="Nav-items-ul">
                <li>Love Music Forever</li>
                <li>Browse Channels</li>
            </ul> */}
        </div>
    )
}

export default sideNav;