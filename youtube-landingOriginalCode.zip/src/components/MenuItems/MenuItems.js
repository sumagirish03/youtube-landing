import React from "react";

import './MenuItems.css';

const MenuItems = ({ selected, Icon, title }) => {

    return (
        <div className={`MenuItems ${selected ? 'selected' : ''}`}>
            <Icon className='MenuItems-icon' />
            <h2 className='MenuItems-title'>{title}</h2>
        </div>
    )
}

export default MenuItems;