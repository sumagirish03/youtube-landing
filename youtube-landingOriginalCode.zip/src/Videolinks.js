import React from 'react'

function Videolinks({ yt_img, prof_img, title }) {
    return (
        <div className="yt-snaps">
            <div className="video-img">
                <img src={yt_img} alt="img" className="t-img" style={{ width: "100%", height: "100%" }} />
                {/* <div className="prof_img">
                    <img src={prof_img} className="t-img" style={{ "width": "100%" }} />
                </div> */}
                <div>
                    <span> {title}</span>
                </div>
            </div>
        </div>
    )
}

export default Videolinks
