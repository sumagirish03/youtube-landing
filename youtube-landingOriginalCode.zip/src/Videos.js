import React from 'react'
import Filter from "./components/Filter/Filter";
import Videolinks from "./Videolinks";
import "./Videos.css";

const Videos = () => {
    return (
        <div className="shorts">
            <Filter/>
            <div className="yt-link" >
               <Videolinks
                yt_img="https://i.ytimg.com/vi/H7KkNUsMI78/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBbMzTXfyE_bUX5jfcySiLEMcpdIA"
                prof_img=""
                title="Best Player of 2023"               
                />
           
               <Videolinks
                yt_img="https://i.ytimg.com/vi/7Dp-ks7rfqQ/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBbIOU7UMl1n7Y-hWSXRWx8m869iQ"
                prof_img=""
                title="Best Player of 2023"               
                />
         
               <Videolinks
                yt_img="https://i.ytimg.com/vi/_cp02DLratA/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBlYcREE6yKdrsMYu_1xUvRD-qpOA"
                prof_img=""
                title="Gravitas"               
                />

                <Videolinks
                yt_img="https://i.ytimg.com/vi/V9djeWePaQo/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBKgftbt3bWZQrEl7VRAqud9_ul-A"
                prof_img=""
                title="Best Player of 2023"               
                />
                 <Videolinks
                yt_img="https://i.ytimg.com/vi/QBtmcQje11I/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLC0mns8W1FjiQ9xUt5c5107GfYwFA"
                prof_img=""
                title="My Cute Pet"               
                />
                 <Videolinks
                yt_img="https://i.ytimg.com/vi/cb7iKOlytz8/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLAc4kudLf3kjY-lzMOdTyRY69Gbzw"
                prof_img=""
                title="Best Player of 2023"               
                />
                 <Videolinks
                yt_img="https://i.ytimg.com/vi/jZ6AIZ_eGoc/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLBHvE4fONatqKw4MZBIKPKeAwrDpQ"
                prof_img=""
                title="2023 Finals"               
                />
                 <Videolinks
                yt_img="https://i.ytimg.com/vi/C05jFtdQeEc/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDEaC5WjmJ9U9kqMxJoi624Y1xmGw"
                prof_img=""
                title="Best Player of 2023"               
                />
                <Videolinks
                yt_img="https://i.ytimg.com/vi/01Pm_buODc4/hqdefault.jpg?sqp=-oaymwEXCOADEI4CSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLC2bjnrCED_IYueCzyuiAxWKQ1X_w"
                prof_img=""
                title="Happy Songs"               
                />
                <Videolinks
                yt_img="https://i.ytimg.com/vi/7kzIM7CLMGg/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCmfsDkAQnpPzjReIt6yKydyhUe6w"
                prof_img=""
                title="Best Player of 2023"               
                />
                <Videolinks
                yt_img="https://i.ytimg.com/vi/V9X9Ly_6jew/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLDY9QkhhmeY0Ys3wg-w9Ite_OkCIQ"
                prof_img=""
                title="3 Myths of Leadership"               
                />
                <Videolinks
                yt_img="https://i.ytimg.com/vi/eeOrjmplbWM/hqdefault.jpg?sqp=-oaymwEcCOADEI4CSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLC-pKKdUq9nu7HLKHYGbuK570bizw"
                prof_img=""
                title="Isha Flute Music"               
                />

            </div>
        </div>
    )
}

export default Videos;
